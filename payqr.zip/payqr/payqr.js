/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */




Drupal.behaviors.form_submit_processor = {
  attach: function (context, settings) {
    jQuery("form#uc-order-edit-form").submit(function() {
        el = jQuery("input.invoice_check:checked");
        if(el.length > 0)
        {
            return confirm("Вы уверены что хотите выполнить операцию " + el.attr("text"));
        }
    });
  }
}

jQuery(function()
{
    payQR.onPaid(function(data) {
      var msg = "Ваш заказ # " + data.orderId + " создан успешно";
      alert(msg);
      window.location.href = "/";
    });
});
