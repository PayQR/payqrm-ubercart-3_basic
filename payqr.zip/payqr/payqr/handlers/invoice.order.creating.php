<?php
/**
 * Код в этом файле будет выполнен, когда интернет-сайт получит уведомление от PayQR о необходимости создания заказа в учетной системе интернет-сайта.
 * Это означает, что покупатель приблизился к этапу оплаты, а, значит, интернет-сайту нужно создать заказ в своей учетной системе, если такой заказ еще не создан, и вернуть в ответе PayQR значение orderId в объекте "Счет на оплату", если orderId там еще отсутствует.
 *
 * $Payqr->objectOrder содержит объект "Счет на оплату" (подробнее об объекте "Счет на оплату" на https://payqr.ru/api/ecommerce#invoice_object)
 *
 * Ниже можно вызвать функции своей учетной системы, чтобы особым образом отреагировать на уведомление от PayQR о событии invoice.order.creating.
 *
 * Важно: после уведомления от PayQR об invoice.order.creating в содержании конкретного объекта "Счет на оплату" должен быть обязательно заполнен параметр orderId (если он не заполнялся на уровне кнопки PayQR). По правилам PayQR оплата заказа не может быть начата до тех пор, пока в счете не появится номер заказа (orderId). Если интернет-сайт не ведет учет заказов по orderId, то на данном этапе можно заполнить параметр orderId любым случайным значением, например, текущими датой и временем. Также важно, что invoice.order.creating является первым и последним этапом, когда интернет-сайт может внести коррективы в параметры заказа (например, откорректировать названия позиций заказа).
 *
 * Часто используемые методы на этапе invoice.order.creating:
 *
 * * Получаем объект адреса доставки из "Счета на оплату"
 * $Payqr->objectOrder->getDelivery();
 * * вернет:
 * "delivery": { "country": "Россия", "region": "Москва", "city": "Москва", "zip": "115093", "street": "Дубининская ул.", "house": "80", "comment": "У входа в автосалон Хонда", }
 *
 * * Получаем объект содержания корзины из "Счета на оплату"
 * $Payqr->objectOrder->getCart();
 * * вернет:
 * [{ "article": "5675657", "name": "Товар 1", "imageUrl": "http://goods.ru/item1.jpg", "quantity": 5, "amount": 19752.25 }, { "article": "0", "name": "PROMO акция", "imageUrl": "http://goods.ru/promo.jpg", }]
 *
 * * Обновляем содержимое корзины в объекте "Счет на оплату" в PayQR
 * $Payqr->objectOrder->setCart($cartObject);
 *
 * * Получаем объект информации о покупателе из "Счета на оплату"
 * $Payqr->objectOrder->getCustomer();
 * * вернет:
 * { "firstName": "Иван", "lastName": "Иванов", "phone": "+79111111111", "email": "test@user.com" }
 *
 * * Устанавливаем orderId из учетной системы интернет-сайта в объекте "Счет на оплату" в PayQR
 * $Payqr->objectOrder->setOrderId($orderId);
 *
 * * Получаем сумму заказа из "Счета на оплату"
 * $Payqr->objectOrder->getAmount();
 *
 * * Изменяем сумму заказа в объекте "Счет на оплату" в PayQR (например, уменьшаем сумму, чтобы применить скидку)
 * $Payqr->objectOrder->setAmount($amount);
 *
 * * Если по каким-то причинам нам нужно отменить этот заказ сейчас (работает только при обработке события invoice.order.creating)
 * $Payqr->objectOrder->cancelOrder(); вызов этого метода отменит заказ
 */
function payqr_invoice_order_creating($Payqr)
{
    global $user;
    $cartObject = $Payqr->objectOrder->getCart();
    $userObject = $Payqr->objectOrder->getCustomer();
    $delivObject = $Payqr->objectOrder->getDelivery();
    $products = array();
    foreach ($cartObject as $k=>$item)
    {
        if($product = node_load($item->article))
        {            
            $product->qty = $item->quantity;
            $item->amount = $item->quantity * $product->price;
            $products[] = $product;    
        }
        else
        {
            unset($cartObject[$k]);
        }
    }
    //если товары переданные в магазин не валидны то сразу отменяем заказ
    if(count($products) == 0){
        $Payqr->objectOrder->cancelOrder();
    }
    $Payqr->objectOrder->setCart($cartObject);
    $customerObject = $Payqr->objectOrder->getCustomer();
    $order = uc_order_new($user->uid);
    //$order = uc_order_load(25);    
    $order->primary_email = $userObject->email;
    $order->billing_phone = $userObject->phone;
    $order->billing_first_name = $userObject->firstName . " " . $userObject->middleName;
    $order->billing_last_name = $userObject->lastName;    
    $order->billing_city = $delivObject->city;
    $order->billing_street1 = ($delivObject->street ? "ул. {$delivObject->street}" : "") . ($delivObject->house ? " д.{$delivObject->house}" : "") . ($delivObject->unit ? " к.{$delivObject->unit}" : "") . ($delivObject->flat ? " кв.{$delivObject->flat}" : "");
    
    $order->delivery_phone = $order->billing_phone;
    $order->delivery_first_name = $order->billing_first_name;
    $order->delivery_last_name = $order->billing_last_name;    
    $order->delivery_city = $order->billing_city;
    $order->delivery_street1 = $order->billing_street1;
    
    $order->products = $products;    
    $code = $Payqr->objectOrder->getPromo();
    if($code)
    {        
        $coupon = uc_coupon_validate($code, $order);
        if($coupon->valid)
        {
            $order->line_items[] = uc_order_line_item_add($order->order_id, 'coupon', $coupon->title, -$coupon->value);
            //save coupon here because hook will not work (hook use session data that is empty)
            db_insert('uc_coupons_orders')
                ->fields(array(
                  'cid' => 1,
                  'oid' => $order->order_id,
                  'code' => $coupon->code,
                  'value' => $coupon->value,
                ))->execute();
        }
    }
    //if we have delivery
    if($delivery = $Payqr->objectOrder->getDeliveryCasesSelected())
    {
        $order->quote["method"] = $delivery->article;
        $order->quote["accessorials"] = 0;
        $order->quote["rate"] = $delivery->amountTo;
        $order->line_items[] = uc_order_line_item_add($order->order_id, 'shipping', $delivery->article, $delivery->amountTo);
    }
    uc_order_save($order);
    $Payqr->objectOrder->setAmount($order->order_total);
    $orderId = $order->order_id;    
    uc_order_update_status($orderId, variable_get("payqr_order_status_created"));
    db_insert('payqr_invoice')
        ->fields(array(
          'order_id' => $order->order_id,
          'invoice_id' => $Payqr->objectOrder->getInvId(),
        ))->execute();
    $Payqr->objectOrder->setOrderId($orderId);
}