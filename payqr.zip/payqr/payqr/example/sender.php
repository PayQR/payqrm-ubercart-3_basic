<?php
/**
 * Примеры запросов в PayQR
 */

require_once '../payqr_config.php';

date_default_timezone_set("Europe/Moscow");

// Методы для работы с объектами "Счет на оплату"

$Payqr_invoice = new payqr_invoice_action();

/**
 * Отменить счет до оплаты (отказаться от оплаты) целиком
 * Подробнее https://payqr.ru/api/ecommerce#invoice_cancel
 */
//$r = $Payqr_invoice->invoice_cancel("inv_fm1zJkaSw0IFWYTQPOsOoE");

/**
 * Отменить счет после оплаты (вернуть деньги) на определенную указанную сумму
 * Подробнее https://payqr.ru/api/ecommerce#invoice_revert
 */
//$r = $Payqr_invoice->invoice_revert("inv_gU7URY7x6RxsXUffZqXLCC", '4.0');

/**
 * Досрочно подтвердить оплату по счету (запустить финансовые расчеты)
 * Подробнее https://payqr.ru/api/ecommerce#invoice_confirm
 */
//$r = $Payqr_invoice->invoice_confirm("inv_gYmLjgYx4jLj664WdzH4l7");

/**
 * Подтвердить исполнение заказа по счету (товар доставлен/услуга оказана)
 * Подробнее https://payqr.ru/api/ecommerce#invoice_execution_confirm
 */
//$r = $Payqr_invoice->invoice_execution_confirm("inv_gYmLjgYx4jLj664WdzH4l7");

/**
 * Дослать/изменить текстовое сообщение в счете
 * Подробнее https://payqr.ru/api/ecommerce#invoice_message
 *
 * Принимает 4 параметра (идентификатор счета и 3 необязательных), можно указать только необходимые для сообщения.
 */
//$r = $Payqr_invoice->invoice_message("inv_gU7URY7x6RxsXUffZqXLCC", "Сообщение", "http://goods.ru/message.jpg", "http://goods.ru/details");

/**
 * Получить информацию о счете по его идентификатору в PayQR (актуализировать)
 * Подробнее https://payqr.ru/api/ecommerce#invoice_get
 */
//$r = $Payqr_invoice->get_invoice("inv_hDgl5ZXmi6bZLU402aZ7qi");


// Методы для работы с объектами "Возвраты"

$Payqr_revert = new payqr_revert_action();

/**
 * Получить информацию о возврате по его идентификатору в PayQR (актуализировать)
 * Подробнее https://payqr.ru/api/ecommerce#revert_get
 */
//$r = $Payqr_revert->get_revert("rvt_hgBh5pbI0h8zl2kE5vBUfg");